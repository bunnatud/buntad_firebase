// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyCpdhzZH_7MR0nGQ-KNkw0EvX9bUYTE7FA",
  authDomain: "buntad-54952.firebaseapp.com",
  projectId: "buntad-54952",
  storageBucket: "buntad-54952.appspot.com",
  messagingSenderId: "583272437930",
  appId: "1:583272437930:web:9996da70a9d7f63d79d8d3",
  measurementId: "G-N0L0H4YMYC",
});

const db = getFirestore(firebaseApp);
export default db;
